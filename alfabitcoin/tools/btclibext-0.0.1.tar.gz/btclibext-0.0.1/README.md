# Example Library

A simple example math library.

## Installation

pip install example_library

