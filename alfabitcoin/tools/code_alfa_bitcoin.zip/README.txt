
Código necesario para la generación de las gráficas de Alfa Bitcoin

En el fichero zip se incluyen 4 directorios:

    html. Con los ficheros de las gráficas.
    
    json. Con los ficheros de datos en formato JSON.

    ddbb. Es un export con las tablas y los datos para una base de datos PostgreSQL.
          Se restaura con el comando:
    	      pg_restore -U [username] -d [database] [dump_file]	

    code. Con los scripts Python con los que se extraen los datos y se generan los ficheros.

	  config.ini 	-> Configuración de la base de datos
	  config_alfabitcoin.py -> Directorio donde se generarán los gráficos
	  packages.sh 	-> Instalación de las librerías de Python necesarias 
	  btc-alfabitcoin-json.sh -> Generación de los ficheros de datos json. Ejecución diaria
	  btc-alfabitcoin-daily.py -> Obtención de datos. Ejecución diaria
