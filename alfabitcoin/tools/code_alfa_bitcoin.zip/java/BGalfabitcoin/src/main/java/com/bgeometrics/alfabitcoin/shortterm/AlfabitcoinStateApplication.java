package com.bgeometrics.alfabitcoin.shortterm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.bgeometrics.alfabitcoin.shortterm.AlfabitcoinState;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.bgeometrics.alfabitcoin.shortterm")
public class AlfabitcoinStateApplication {

    public static void main(String[] args) {
        SpringApplication.run(AlfabitcoinStateApplication.class, args);
    }
}
