package com.bgeometrics.alfabitcoin.shortterm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import com.bgeometrics.alfabitcoin.shortterm.AlfabitcoinState;
import com.bgeometrics.alfabitcoin.shortterm.AlfabitcoinStateRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.math.RoundingMode;

@Service
public class AlfabitcoinStateService {
    static final Logger logger = LogManager.getLogger(AlfabitcoinStateService.class);

    @Autowired
    private AlfabitcoinStateRepository alfabitcoinStateRepository;

    public AlfabitcoinState saveAlfabitcoinState(AlfabitcoinState alfabitcoinState) {
        BigDecimal metrics = new BigDecimal(9);
        BigDecimal total =   
            alfabitcoinState.getFunding_rate().add( 
            alfabitcoinState.getGeopolitical_risk().add( 
            alfabitcoinState.getGlobal_liquidity().add(
            alfabitcoinState.getMiners_sale().add( 
            alfabitcoinState.getNvts().add( 
            alfabitcoinState.getShort_term_trend().add( 
            alfabitcoinState.getState_industry().add( 
            alfabitcoinState.getSth_realized_price().add( 
            alfabitcoinState.getVdd())))))))) ;

        BigDecimal average = total.divide(metrics, 2, RoundingMode.HALF_UP);
        //logger.info(average);    

        alfabitcoinState.setAverage(average);
        return alfabitcoinStateRepository.save(alfabitcoinState);
    }

    public List<AlfabitcoinState> getAllAlfabitcoinStates() {
        return alfabitcoinStateRepository.findAll();
    }

    public AlfabitcoinState getAlfabitcoinStateById(Long id) {
        return alfabitcoinStateRepository.findById(id).orElse(null);
    }

    public void deleteAlfabitcoinState(Long id) {
        alfabitcoinStateRepository.deleteById(id);
    }

    public Optional<AlfabitcoinState> updateAlfabitcoinState(Long id, AlfabitcoinState alfabitcoinStateDetails) {
        return alfabitcoinStateRepository.findById(id).map(alfabitcoinState -> {

            BigDecimal metrics = new BigDecimal(9);
            alfabitcoinState.setFunding_rate(alfabitcoinStateDetails.getFunding_rate());
            alfabitcoinState.setGeopolitical_risk(alfabitcoinStateDetails.getGeopolitical_risk());
            alfabitcoinState.setGlobal_liquidity(alfabitcoinStateDetails.getGlobal_liquidity());
            alfabitcoinState.setMiners_sale(alfabitcoinStateDetails.getMiners_sale());
            alfabitcoinState.setNvts(alfabitcoinStateDetails.getNvts());
            alfabitcoinState.setShort_term_trend(alfabitcoinStateDetails.getShort_term_trend());
            alfabitcoinState.setState_industry(alfabitcoinStateDetails.getState_industry());
            alfabitcoinState.setSth_realized_price(alfabitcoinStateDetails.getSth_realized_price());
            alfabitcoinState.setTheDate(alfabitcoinStateDetails.getTheDate());
            alfabitcoinState.setVdd(alfabitcoinStateDetails.getVdd());

            BigDecimal total =   
                alfabitcoinStateDetails.getFunding_rate().add( 
                alfabitcoinStateDetails.getGeopolitical_risk().add( 
                alfabitcoinStateDetails.getGlobal_liquidity().add(
                alfabitcoinStateDetails.getMiners_sale().add( 
                alfabitcoinStateDetails.getNvts().add( 
                alfabitcoinStateDetails.getShort_term_trend().add( 
                alfabitcoinStateDetails.getState_industry().add( 
                alfabitcoinStateDetails.getSth_realized_price().add( 
                alfabitcoinStateDetails.getVdd())))))))) ;

            BigDecimal average = total.divide(metrics, 2, RoundingMode.HALF_UP);
            //logger.info(average);    

            alfabitcoinState.setAverage(average);
            return alfabitcoinStateRepository.save(alfabitcoinState);
        });
    }

    public AlfabitcoinState getLastAlfabitcoinState() {
        return alfabitcoinStateRepository.findTopByOrderByIdDesc();
    }
}
