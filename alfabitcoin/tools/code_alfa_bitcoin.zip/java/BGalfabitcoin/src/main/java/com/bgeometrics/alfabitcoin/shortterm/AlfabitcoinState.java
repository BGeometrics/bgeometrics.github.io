package com.bgeometrics.alfabitcoin.shortterm;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "btc_alfabitcoin_state")
public class AlfabitcoinState {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "btc_alfabitcoin_state_generator")
    @SequenceGenerator(name = "btc_alfabitcoin_state_generator", sequenceName = "btc_alfabitcoin_state_seq", allocationSize = 1)
    private Long id;

    @Column(name = "the_date")
    private LocalDate theDate;
    private BigDecimal miners_sale;
    private BigDecimal funding_rate;
    private BigDecimal nvts;
    private BigDecimal sth_realized_price;
    private BigDecimal short_term_trend;
    private BigDecimal global_liquidity;
    private BigDecimal vdd;
    private BigDecimal geopolitical_risk;
    private BigDecimal state_industry;
    private BigDecimal average;

}