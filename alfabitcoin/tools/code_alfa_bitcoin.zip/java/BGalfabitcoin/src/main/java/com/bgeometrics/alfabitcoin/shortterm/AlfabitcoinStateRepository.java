package com.bgeometrics.alfabitcoin.shortterm;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bgeometrics.alfabitcoin.shortterm.AlfabitcoinState;

@Repository
public interface AlfabitcoinStateRepository extends JpaRepository<AlfabitcoinState, Long> {
    AlfabitcoinState findTopByOrderByIdDesc();
}
