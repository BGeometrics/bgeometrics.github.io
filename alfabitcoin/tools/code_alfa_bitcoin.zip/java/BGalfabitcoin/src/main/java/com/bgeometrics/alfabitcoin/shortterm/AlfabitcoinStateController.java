package com.bgeometrics.alfabitcoin.shortterm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import com.bgeometrics.alfabitcoin.shortterm.AlfabitcoinState;
import com.bgeometrics.alfabitcoin.shortterm.AlfabitcoinStateService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v1/alfabitcoin")
public class AlfabitcoinStateController {
    static final Logger logger = LogManager.getLogger(AlfabitcoinStateController.class);

    @Autowired
    private AlfabitcoinStateService alfabitcoinStateService;

    @PostMapping
    public ResponseEntity<AlfabitcoinState> createAlfabitcoinState(@RequestBody AlfabitcoinState alfabitcoinState) {
        AlfabitcoinState savedAlfabitcoinState = alfabitcoinStateService.saveAlfabitcoinState(alfabitcoinState);
        return new ResponseEntity<>(savedAlfabitcoinState, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<AlfabitcoinState>> getAllAlfabitcoinStates() {
        List<AlfabitcoinState> alfabitcoinStates = alfabitcoinStateService.getAllAlfabitcoinStates();
        return new ResponseEntity<>(alfabitcoinStates, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AlfabitcoinState> getAlfabitcoinStateById(@PathVariable Long id) {
        AlfabitcoinState alfabitcoinState = alfabitcoinStateService.getAlfabitcoinStateById(id);
        if (alfabitcoinState != null) {
            return new ResponseEntity<>(alfabitcoinState, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAlfabitcoinState(@PathVariable Long id) {
        alfabitcoinStateService.deleteAlfabitcoinState(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AlfabitcoinState> updateAlfabitcoinState(@PathVariable Long id, @RequestBody AlfabitcoinState alfabitcoinStateDetails) {
        Optional<AlfabitcoinState> updatedAlfabitcoinState = alfabitcoinStateService.updateAlfabitcoinState(id, alfabitcoinStateDetails);
        return updatedAlfabitcoinState.map(ResponseEntity::ok)
                             .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/last")
    public ResponseEntity<AlfabitcoinState> getLastAlfabitcoinState() {
        AlfabitcoinState alfabitcoinState = alfabitcoinStateService.getLastAlfabitcoinState();
        return ResponseEntity.ok(alfabitcoinState);
    }
}
