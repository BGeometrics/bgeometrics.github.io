#!/bin/bash

sudo docker stop -t 2 bgalfabitcoin

# sudo docker rm bgalfabitcoin
