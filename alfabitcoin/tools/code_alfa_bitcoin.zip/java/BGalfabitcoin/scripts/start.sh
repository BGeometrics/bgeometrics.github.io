#!/bin/bash

#/usr/bin/docker start bgalfabitcoin

#sudo docker build -t bgalfabitcoin/v0.0.1 .

cd /home/simon/proyectos/BGalfabitcoin
sudo docker run -d -p 8091:8091 -v logs-bgalfabitcoin:/var/log/bgalfabitcoin --name bgalfabitcoin bgalfabitcoin/v0.0.1


