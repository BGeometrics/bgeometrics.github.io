#!/bin/bash

DIR_DEV=/home/simon/proyectos/BGalfabitcoin
VERSION=v0.0.1

cd $DIR_DEV

sudo docker stop bgalfabitcoin
sudo docker rm bgalfabitcoin

mvn clean package
sudo docker build -t bgalfabitcoin/$VERSION .
sudo docker run -d -p 8091:8091 -v logs-bgalfabitcoin:/var/log/bgalfabitcoin --name bgalfabitcoin bgalfabitcoin/$VERSION
#sudo docker run -d -p 8091:8091 -v logs-bgalfabitcoin:/tmp --name bgalfabitcoin bgalfabitcoin/$VERSION
