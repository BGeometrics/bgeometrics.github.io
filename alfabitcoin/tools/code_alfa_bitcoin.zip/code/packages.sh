#!/bin/bash

# Example create python virtual env 
# sudo apt install python3-venv
# python3 -m venv bitcoin-scripts-env
# source bitcoin-scripts-env/bin/activate

pip install pandas
pip install pandas-datareader
pip install yfinance
pip install kaleido
pip install python-binance
pip install plotly
pip install requests
pip install sklearn
pip install seaborn
pip install matplotlib
pip install psycopg2-binary
pip install coinmetrics
pip install coinmetrics.api_client
pip install --upgrade --no-cache-dir git+https://github.com/rongardF/tvdatafeed.git
pip install btclibext-*.tar.gz

