import sys
import bitcoin_utils as utils


args = sys.argv[1:]

if len(args) > 1:
    raise SystemExit(USAGE)

if len(args) == 0:
    directory_path = '.'
else:
    directory_path = args[0]

file_extension = '.py'  
old_text = """utils.download_page("""
new_text = """utils.download_page_check("""

utils.replace_text_in_directory(directory_path, old_text, new_text, file_extension)

