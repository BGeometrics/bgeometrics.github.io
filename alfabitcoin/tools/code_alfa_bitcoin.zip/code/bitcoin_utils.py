#!/usr/bin/python3

import sys
import os
import re
import psycopg2
import json
import requests
import numpy as np
import pandas as pd
from datetime import date, timedelta, datetime, timezone
from coinmetrics.api_client import CoinMetricsClient
from configparser import ConfigParser
from decimal import Decimal
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.io as pio
import plotly
import plotly.graph_objects as go


#Read config.ini file
config_object = ConfigParser()
config_object.read("config.ini")
database = config_object["DATABASE"]
the_host = database["host"]
the_database = database["database"]
the_user = database["user"]
the_password = database["password"]
the_port = database["port"]
serverconfig = config_object["SERVERCONFIG"]
domain = serverconfig["domain"]
dir_dump = serverconfig["dir_dump"]
appconfig = config_object["APPCONFIG"]


class Indicator:
    nupl = 0
    s2fd = 0
    mvrvzscore = 0
    puell_multiple = 0
    reserve_risk = 0
    sopr = 0
    hodl_waves = 0
    the_date = ""
    mayer_multiple = 0
    realized_price = 0
    price = 0


def get_indicator_limit(_ind):
    ind_limit = Indicator()
    _indicator = ['nupl', 's2fd', 'mvrvzscore', 'puell_multiple', 'reserve_risk', 'sopr', 'mayer_multiple']

    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()

    for indi in _indicator:
        sql = "SELECT the_index, soft_buy FROM btc_index_threshold WHERE the_index = '" + indi + "';"

        cur.execute(sql);
        records = cur.fetchall()

        for row in records:
            if row[0] == 'nupl':
                ind_limit.nupl = float(row[1])
            elif row[0] == 's2fd':
                ind_limit.s2fd = float(row[1])
            elif row[0] == 'mvrvzscore':
                ind_limit.mvrvzscore = float(row[1])
            elif row[0] == 'puell_multiple':
                ind_limit.puell_multiple = float(row[1])
            elif row[0] == 'reserve_risk':
                ind_limit.reserve_risk = float(row[1])
            elif row[0] == 'sopr':
                ind_limit.sopr = float(row[1])
            elif row[0] == 'mayer_multiple':
                ind_limit.mayer_multiple = float(row[1])

    ind_limit.realized_price = _ind.realized_price * 1.5  # < #Se podría revisar el límite

    cur.close()
    con.close()

    return ind_limit

def get_indicator_limit_strong():
    ind_limit = Indicator()
    _indicator = ['nupl', 's2fd', 'mvrvzscore', 'puell_multiple', 'reserve_risk', 'sopr', 'mayer_multiple']

    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()

    for indi in _indicator:
        sql = "SELECT the_index, strong_buy FROM btc_index_threshold WHERE the_index = '" + indi + "';"

        cur.execute(sql);
        records = cur.fetchall()

        for row in records:
            if row[0] == 'nupl':
                ind_limit.nupl = float(row[1])
            elif row[0] == 's2fd':
                ind_limit.s2fd = float(row[1])
            elif row[0] == 'mvrvzscore':
                ind_limit.mvrvzscore = float(row[1])
            elif row[0] == 'puell_multiple':
                ind_limit.puell_multiple = float(row[1])
            elif row[0] == 'reserve_risk':
                ind_limit.reserve_risk = float(row[1])
            elif row[0] == 'sopr':
                ind_limit.sopr = float(row[1])
            elif row[0] == 'mayer_multiple':
                ind_limit.mayer_multiple = float(row[1])

    #ind_limit.realized_price = _ind.realized_price
    cur.close()
    con.close()

    return ind_limit

def get_indicator_limit_max():
    ind_limit = Indicator()
    _indicator = ['nupl', 's2fd', 'mvrvzscore', 'puell_multiple', 'reserve_risk', 'sopr', 'mayer_multiple']

    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()

    for indi in _indicator:
        sql = "SELECT the_index, history_max FROM btc_index_threshold WHERE the_index = '" + indi + "';"

        cur.execute(sql);
        records = cur.fetchall()

        for row in records:
            if row[0] == 'nupl':
                ind_limit.nupl = float(row[1])
            elif row[0] == 's2fd':
                ind_limit.s2fd = float(row[1])
            elif row[0] == 'mvrvzscore':
                ind_limit.mvrvzscore = float(row[1])
            elif row[0] == 'puell_multiple':
                ind_limit.puell_multiple = float(row[1])
            elif row[0] == 'reserve_risk':
                ind_limit.reserve_risk = float(row[1])
            elif row[0] == 'sopr':
                ind_limit.sopr = float(row[1])
            elif row[0] == 'mayer_multiple':
                ind_limit.mayer_multiple = float(row[1])

    cur.close()
    con.close()

    return ind_limit

def get_indicator_limit_min():
    ind_limit = Indicator()
    _indicator = ['nupl', 's2fd', 'mvrvzscore', 'puell_multiple', 'reserve_risk', 'sopr', 'mayer_multiple']

    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()

    for indi in _indicator:
        sql = "SELECT the_index, history_min FROM btc_index_threshold WHERE the_index = '" + indi + "';"

        cur.execute(sql);
        records = cur.fetchall()

        for row in records:
            if row[0] == 'nupl':
                ind_limit.nupl = float(row[1])
            elif row[0] == 's2fd':
                ind_limit.s2fd = float(row[1])
            elif row[0] == 'mvrvzscore':
                ind_limit.mvrvzscore = float(row[1])
            elif row[0] == 'puell_multiple':
                ind_limit.puell_multiple = float(row[1])
            elif row[0] == 'reserve_risk':
                ind_limit.reserve_risk = float(row[1])
            elif row[0] == 'sopr':
                ind_limit.sopr = float(row[1])
            elif row[0] == 'mayer_multiple':
                ind_limit.mayer_multiple = float(row[1])

    cur.close()
    con.close()

    return ind_limit

#TODO: Remove
#def get_indicator_percentage_min_max(_ind, _ind_strong_buy, _ind_min, _ind_max):
#    ind_percentage = Indicator()
#    ind_percentage.nupl = get_percentage(_ind.nupl, _ind_strong_buy.nupl, _ind_min.nupl, _ind_max.nupl)
#    ind_percentage.s2fd = get_percentage(_ind.s2fd, _ind_strong_buy.s2fd, _ind_min.s2fd, _ind_max.s2fd)
#    ind_percentage.mvrvzscore = get_percentage(_ind.mvrvzscore, _ind_strong_buy.mvrvzscore, _ind_min.mvrvzscore, _ind_max.mvrvzscore)
#    ind_percentage.puell_multiple = get_percentage(_ind.puell_multiple, _ind_strong_buy.puell_multiple, _ind_min.puell_multiple, _ind_max.puell_multiple)
#    ind_percentage.reserve_risk = get_percentage(_ind.reserve_risk, _ind_strong_buy.reserve_risk, _ind_min.reserve_risk, _ind_max.reserve_risk)
#    ind_percentage.sopr = get_percentage(_ind.sopr, _ind_strong_buy.sopr, _ind_min.sopr, _ind_max.sopr)
#    ind_percentage.mayer_multiple = get_percentage(_ind.mayer_multiple, _ind_strong_buy.mayer_multiple, _ind_min.mayer_multiple, _ind_max.mayer_multiple)
#
#    return ind_percentage

#TODO: Remove
#def get_indicator_percentage(_ind):
#    _ind_max = get_indicator_limit_max()
#    _ind_min = get_indicator_limit_min()
#    _ind_strong_buy = get_indicator_limit_strong()
#    ind_percentage = get_indicator_percentage_min_max(_ind, _ind_strong_buy, _ind_min, _ind_max)
#
#    return ind_percentage

# Formula: (umbral_sell - val ) * 100 / (umbral_sell - umbral_buy)
def get_indicator_percent(_val, _ind):
    _sql = "SELECT strong_buy, strong_sell FROM btc_index_threshold WHERE the_index = '" + _ind + "';"
    _strong_buy, _strong_sell = get_value2_sql(_sql)
    _per = (float(_strong_sell) - float(_val)) * 100 / (float(_strong_sell) - float(_strong_buy))

    return _per

#TODO: Remove
# Formula
# 100 - (_val - _umbral_strong) * 100 / (_max - _min)
# (_max - val ) * 100 / (_max - umbral_strong)
# (umbral_sell - val ) * 100 / (umbral_sell - umbral_buy)
#def get_percentage(_val, _strong_buy, _min, _max):
#    #return 100 - ((_val - _strong_buy) * 100 / (_max - _min))
#    return (_max - _val) * 100 / (_max - _strong_buy)

def get_indicator():
    ind = Indicator()
    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()
    sql = """SELECT nupl, s2fd, mvrvzscore, puell_multiple, reserve_risk, sopr, hodl_waves,
            TO_CHAR(the_date AT TIME ZONE 'UTC', 'Day DD Mon YYYY HH24:MI:SS') || ' UTC',
            mayer_multiple, pi_cycle
            FROM btc_buy_indicator ORDER BY the_date DESC LIMIT 1;"""

    cur.execute(sql);
    records = cur.fetchall()

    for row in records:
        ind.nupl = float(row[0])
        ind.s2fd = float(row[1])
        ind.mvrvzscore = float(row[2])
        ind.puell_multiple = float(row[3])
        ind.reserve_risk = float(row[4])
        ind.sopr = float(row[5])
        ind.hodl_waves = float(row[6])
        ind.the_date = str(row[7])
        ind.mayer_multiple = float(row[8])

    sql2 = """SELECT realized_price, supply_current
        FROM btc_realized_price ORDER BY the_date desc limit 1;"""

    cur.execute(sql2);
    records = cur.fetchall()

    for row in records:
        ind.realized_price = float(row[0]/row[1])

    sql3 = """SELECT price_usd
        FROM btc_price_usd ORDER BY the_date desc limit 1;"""

    cur.execute(sql3);
    records = cur.fetchall()

    for row in records:
        ind.price = float(row[0])

    cur.close()
    con.close()

    return ind

def get_value1_sql(_sql):
    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()

    cur.execute(_sql);
    records = cur.fetchall()

    for row in records:
        _one = row[0]

    cur.close()
    con.close()

    return _one

def get_value1_sql_saturno(_sql):
    con = psycopg2.connect(database='postgres', user='postgres', password='postgres', host='192.168.1.52', port='5432')
    cur = con.cursor()

    cur.execute(_sql);
    records = cur.fetchall()

    for row in records:
        _one = row[0]

    cur.close()
    con.close()

    return _one

def get_value1_sql_conn(_sql, _conn):
    _one = ""

    try:
        cur = _conn.cursor()
        cur.execute(_sql);
        records = cur.fetchall()

        for row in records:
            _one = row[0]

        cur.close()

    except Exception as error:
        print("#### Error, an exception occurred:", error)

    return _one

def get_value2_sql(_sql):
    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()

    cur.execute(_sql);
    records = cur.fetchall()

    for row in records:
        _one = row[0]
        _two = row[1]

    cur.close()
    con.close()

    return _one, _two

def get_value2_sql_saturno(_sql):
    con = psycopg2.connect(database='postgres', user='postgres', password='postgres', host='192.168.1.52', port='5432')
    cur = con.cursor()

    cur.execute(_sql);
    records = cur.fetchall()

    for row in records:
        _one = row[0]
        _two = row[1]

    cur.close()
    con.close()

    return _one, _two

def get_value4_sql(_sql):
    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()

    cur.execute(_sql);
    records = cur.fetchall()

    for row in records:
        _one = row[0]
        _two = row[1]
        _three = row[2]
        _four = row[3]

    cur.close()
    con.close()

    return _one, _two, _three, _four

def get_value_sql(_sql):
    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()
    cur.execute(_sql);
    _columns = cur.description
    _result = {}

    for value in cur.fetchall():
        for (index,column) in enumerate(value):
            _result[_columns[index][0]] =  column

    cur.close()
    con.close()

    return _result


def get_data_sql(_sql):
    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()
    cur.execute(_sql)

    _x = ""
    _y = ""

    for row in cur.fetchall():
        _x = _x + "'" + str(row[1]) + "',"
        _y = _y + str(row[0]) + ","

    _x = _x[:-1]
    _y = _y[:-1]

    cur.close()
    con.close()

    return _x, _y


def get_metric_coinmetrics(_client, _metric, _day_ini, _day_end):
    _ret = ""
    _date = ""

    for metric_data in _client.get_asset_metrics(assets='btc',
                                            metrics=[_metric],
                                            frequency='1d',
                                            start_time=_day_ini,
                                             end_time=_day_end):
        _ret = metric_data[_metric]
        _date = metric_data['time'][0:10]

    return _ret, _date


def get_date(_date):
    _pag = """<!DOCTYPE html><html><head><title>
        </title><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'>
        <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css'></head>
        <body><div class='container'>
        <h4>""" + _date + """  (Last update)</h4>
        </div></body></html>"""

    return _pag

def get_guage(_tittle, _value, _value_bar, _indicator, _indicator_desc, _link="", _color_bar="rgb(127,127,127,.2)",
        _linear_gradient="#5736cb, #aa2dc1 50%, #d9003a"):
    if float(_value_bar) > 0.5 :
        _value_bar_str = "0.5"
    else :
        _value_bar_str = str(_value_bar)

    _value_str = str(_value)

    _gauge = """<!DOCTYPE html>
    <html>
    <head>
        <title>""" + _tittle + """</title>
        <link rel="stylesheet" type="text/css" href="css.css">
        <style>
            @import url(https://fonts.googleapis.com/css?family=Arimo);
            @import url(https://fonts.googleapis.com/css?family=Didact+Gothic);
            html {
                font-family:Futura, Helvetica;
                color: black;
                background-color: white;
            }
            html, body{
                margin: 0px;
                padding: 0px;
            }
            .info-g{
                position: absolute;
                z-index: 3;
                width:100%;
                height:200px;
                text-align: center;
                top: 50%;
            }
            h1{
                font-family: 'Didact Gothic', sans-serif;
                margin-bottom: -10px;
            }
            p{
                font-family: 'Arimo', sans-serif;
                font-size: 11pt;
                line-height: 14pt;
            }
            .container{
                width:200px;
                height:100px;
                position: absolute;
                top: 30%;
                left: 50%;
                overflow: hidden;
                text-align: center;
                transform: translate(-50%, -50%);
            }
            .gauge-a{
                z-index: 1;
                position: absolute;
                background-color: """ + _color_bar + """;
                width: 200px;
                height: 100px;
                top: 0%;
                border-radius:250px 250px 0px 0px ;
            }
            .gauge-b{
                z-index: 3;
                position: absolute;
                background-color: rgb(255,255,0);
                width: 125px;
                height: 64px;
                top: 38px;
                margin-left: 37px;
                margin-right: auto;
                border-radius:250px 250px 0px 0px ;
            }
            .gauge-c{
                z-index: 2;
                position: absolute;
                background: linear-gradient(""" + _linear_gradient + """);
                width: 200px;
                height: 100px;
                top: 100px;
                margin-left: auto;
                margin-right: auto;
                border-radius:0px 0px 200px 200px ;
                transform-origin:center top;
                transition: all 1.3s ease-in-out;
                transform:rotate(""" + _value_bar_str + """turn);
                color: rgba(255,255,255,1);
            }
            .container:hover .gauge-data{
                color: rgba(255,255,255,1);
            }
            .gauge-data{
                z-index: 4;
                color: black;
                font-size: 0.7em;
                line-height: 25px;
                position: absolute;
                width: 200px;
                height: 100px;
                top: 30px;
                margin-left: auto;
                margin-right: auto;
                transition: all 1s ease-out;
            }
            .gauge-text{
                z-index: 4;
                color: black;
                font-size: 0.7em;
                line-height: 25px;
                position: absolute;
                width: 200px;
                height: 100px;
                top: 50px;
                margin-left: auto;
                margin-right: auto;
                transition: all 1s ease-out;
            }
            .gauge-text-right{
                z-index: 4;
                color: black;
                font-size: 0.7em;
                line-height: 25px;
                font-weight: bold;
                position: absolute;
                width: 200px;
                height: 100px;
                top: 80px;
                margin-left: 80px;
                margin-right: auto;
                transition: all 1s ease-out;
            }
            .gauge-text-left{
                z-index: 4;
                color: black;
                font-size: 0.7em;
                line-height: 25px;
                font-weight: bold;
                position: absolute;
                width: 200px;
                height: 100px;
                top: 80px;
                margin-left: -80px;
                margin-right: auto;
                transition: all 1s ease-out;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="gauge-a"></div>
            <div class="gauge-b"></div>
            <div class="gauge-c"></div>
            <a href='""" + _link + """' target='_blank'>
                <div class="gauge-data"><h1 id="percent">""" + _value_str + """%</h1><h3>""" + _indicator_desc + """</h3></div>
            </a>
            <div class="gauge-text-right">Buy</div>
            <div class="gauge-text-left">Sell</div>
        </div>
    </body>
    </html>"""

    return _gauge

def get_foot():
    _foot = """<a href='https://bgeometrics.com' target='_blank'>
        <img src='https://bgeometrics.github.io/Logo_BGeometrics.png' alt='BGeometrics' width='20%' height='20%'>
        </a></div></body></html>"""

    return _foot

def get_foot_chart(_url, _link=""):
    _zoom = """&nbsp;<a id='zoom' href='""" + _url + """' target="_blank" style='text-decoration:none'>
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"></path>
    </svg>&nbsp;
    <span class='oneFont'>Open chart</span></a>"""

    _foot = """</script>""" + _zoom + """<p><a href="https://bgeometrics.com" target="_blank"><img src="https://bgeometrics.github.io/Logo_BGeometrics.png" alt="BGeometrics" width="15%" height="15%"></a></p></div>""" + _link + """</body></html>"""

    return _foot

def get_head_chart(_tittle):
    _head = """<!DOCTYPE html><html><head><title>""" + _tittle + """</title><script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <style>a#zoom .oneFont {font-family: Arial, Helvetica, sans-serif;}</style>
        </head><body><h1></h1><div id="chart"><script>"""

    return _head

def get_annotations(_text):
    _ret = """ 'annotations': [{'font': {'color': 'rgb(50,50,50)', 'family': 'Courier New, monospace', 'size': 16}, 'opacity': 0.75, 'showarrow': false, 'text': '""" + _text + """', 'x': 0.5, 'xref': 'paper', 'y': 1.0, 'yref': 'paper'}]"""

    return _ret

def get_slider(_date_ini, _date_end):
    _slider = """range: ['""" + _date_ini + """', '""" + _date_end + """'], rangeselector: selectorOptions, rangeslider: {}"""

    return _slider

def get_selector_options():
    _selectorOptions = """var selectorOptions = {
    buttons: [{
        step: 'month',
        stepmode: 'backward',
        count: 1,
        label: '1m'
    }, {
        step: 'month',
        stepmode: 'backward',
        count: 6,
        label: '6m'
    }, {
        step: 'year',
        stepmode: 'todate',
        count: 1,
        label: 'YTD'
    }, {
        step: 'year',
        stepmode: 'backward',
        count: 1,
        label: '1y'
    }, {
        step: 'all',
    }],
    };\n"""

    return(_selectorOptions)

def file_writer(_file, _gauge):
    f = open(_file, 'w')
    f.write(_gauge)
    f.close()

def get_price():
    _sql = "SELECT btc_price_close, the_date FROM btc_price ORDER BY the_date DESC LIMIT 1;"
    _price_close, _date = get_value2_sql(_sql)

    return(_price_close, _date)

def get_realized_price():
    #_sql = "SELECT realized_price / supply_current, the_date FROM btc_realized_price ORDER BY the_date DESC LIMIT 1;"
    _sql = "SELECT realized_price, the_date FROM btc_realized_price ORDER BY the_date DESC LIMIT 1;"
    _realized_price_adj, _date = get_value2_sql(_sql)

    return(_realized_price_adj, _date)

def get_delta_cap(_realized_price, _the_date):
    _sql = "select AVG(realized_price) avg from btc_realized_price where the_date >= '2010-09-01' and the_date <= '" + str(_the_date) + "';"  
    res = get_value_sql(_sql)
    _realized_price_avg = res['avg']

    if _realized_price_avg == None:
        _realized_price_avg = 0
        _realized_price = 0

    _delta_cap = float(_realized_price) - float(_realized_price_avg)

    return(_delta_cap, _the_date)

def get_price_now():
    url = 'https://bitcoinition.com/current.json'
    #today = date.today().strftime("%Y-%m-%d")
    #d_utc = datetime.utcnow().date().strftime("%Y-%m-%d")
    dt_now = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
    req = requests.get(url)

    data = json.loads(req.text)
    btc_price_now = float(data['data']['btc_price'])

    return(btc_price_now, dt_now)

def get_price_now_binance():
    d_0 = date.today()
    d0 = d_0.strftime("%Y-%m-%d 00:00:00")

    _sql = """
        SELECT close
        FROM btc_ohlc_1m
        WHERE the_date = '""" + d0 + """';
    """
    price_now = get_value1_sql_saturno(_sql)
    sql = "INSERT INTO btc_price_usd (asset, price_usd, the_date) VALUES ('btc'," + str(price_now) + ", '" + str(d0) + "');"
    sql_execute(sql)
    print("INSERT price_usd Binance")
    print(sql)

    return(price_now, d_0)


# Get BTP (Bitcoin Price Temperature)
# Precio de hoy menos la media móvil de hace 4 años todo dividido por la desviación estándar
# btp[i] = (price[i] — mean(price[i<1460])) / sd(price[i<1460])
# Use: utils.get_bpt('2020-12-15')
def get_bpt(_date='CURRENT_DATE'):
    days = 1460
    if _date != 'CURRENT_DATE' :
        _date = "date('" + _date + "')"
        days = 1459

    sql = """SELECT price_usd, the_date FROM btc_price_usd
            WHERE the_date >= (""" + _date + """ - INTERVAL '""" + str(days) + """ day') 
            AND the_date <= """ + _date + """ ORDER BY the_date;"""

    con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    cur = con.cursor()
    cur.execute(sql)

    data = []

    for row in cur.fetchall():
        data.append(row[0])

    cur.close()
    con.close()

    total = sum(data)
    mean = np.mean(data)
    std = np.std(data)
    bpt = (data[-1] - mean) / std

    return(bpt, std)

def get_bpt_band(par, _date='CURRENT_DATE'):
    bpt, std = get_bpt(_date)
    band = par * float(std)

    return(band)

def check_operational():
    ret = False

    url_1 = "https://bitcoin-data.com/alfabitcoin.html"
    url_2 = "https://charts.bgeometrics.com/alfabitcoin.html"

    if requests.get(url_1).status_code == 200:
        ret = True

    elif requests.get(url_2).status_code == 200:
        ret = True

    return ret


def sql_execute(_sql, throw_exception=False):
    try:
        con = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
        cur = con.cursor()
        cur.execute(_sql);
        con.commit()
        cur.close()
        con.close()
    except Exception as error:
        if throw_exception:
            raise Exception("SQL Error")
        else:
            print("#### Error, an exception occurred:", error)
            print("#### SQL: " + _sql)


def sql_execute_conn(_conn, _sql, throw_exception=False):
    try:
        cur = _conn.cursor()
        cur.execute(_sql);
        _conn.commit()
        cur.close()
    except Exception as error:
        if throw_exception:
            raise Exception("SQL Error")
        else:
            print("#### Error, an exception occurred:", error)
            print("#### SQL: " + _sql)


def sql_execute_saturno(_sql, throw_exception=False):
    try:
        con = psycopg2.connect(database='postgres', user='postgres', password='postgres', host='192.168.1.52', port='5432')
        cur = con.cursor()
        cur.execute(_sql);
        con.commit()
        cur.close()
        con.close()
    except Exception as error:
        if throw_exception:
            raise Exception("SQL Error")
        else:
            print("#### Error, an exception occurred:", error)
            print("#### SQL: " + _sql)

def get_value_sql_saturno(_sql):
    con = psycopg2.connect(database='postgres', user='postgres', password='postgres', host='192.168.1.52', port='5432')
    cur = con.cursor()
    cur.execute(_sql);
    _columns = cur.description
    _result = {}

    for value in cur.fetchall():
        for (index,column) in enumerate(value):
            _result[_columns[index][0]] =  column

    cur.close()
    con.close()

    return _result


def get_shapes(_x0, _y0, _x1, _y1, _color, _opacity=0.1):
    shapes = """shapes: [{
            'type': 'rect',
            'xref': 'paper',
            'yref': 'y',
            'x0': """ + str(_x0) + """,
            'y0': """ + str(_y0) + """,
            'x1': """ + str(_x1) + """,
            'y1': """ + str(_y1) + """,
            'fillcolor': '""" + str(_color) + """',
            'opacity': """ + str(_opacity) + """,
            'line': {'width': 0}
        }]"""

    return(shapes)

def get_shapes_ind_strong_buy(_indicator, _bottom=None, _color='green'):
    _sql = "SELECT strong_buy, history_min FROM btc_index_threshold WHERE the_index = '" + _indicator + "';"
    _opacity = 0.1
    ind = get_value_sql(_sql)
    _x0 = 0
    _y0 = ind['strong_buy']
    _x1 = 1
    _y1 = ind['history_min']

    if _bottom is not None:
        _y1 = _bottom

    ret = get_shapes(_x0, _y0, _x1, _y1, _color, _opacity)

    return(ret)

def get_shapes_ind_strong_shell(_indicator, _bottom=None, _color='red'):
    _sql = "SELECT strong_sell, history_max FROM btc_index_threshold WHERE the_index = '" + _indicator + "';"
    _opacity = 0.1
    ind = get_value_sql(_sql)
    _x0 = 0
    _y0 = ind['strong_sell']
    _x1 = 1
    _y1 = ind['history_max']

    if _bottom is not None:
        _y1 = _bottom

    ret = get_shapes(_x0, _y0, _x1, _y1, _color, _opacity)

    return(ret)

def get_dataframe_sql(sql):
    conn = psycopg2.connect(database=the_database, user=the_user, password=the_password, host=the_host, port=the_port)
    data = pd.read_sql_query(sql, conn)
    conn.close()

    return(data)

def get_dataframe_sql_saturno(sql):
    conn = psycopg2.connect(database='postgres', user='postgres', password='postgres', host='192.168.1.52', port='5432')
    data = pd.read_sql_query(sql, conn)
    conn.close()

    return(data)

def get_dataframe_sql_conn(sql, _conn):
    data = pd.read_sql_query(sql, _conn)

    return(data)

def get_dir_repo_git():
    return(serverconfig["dir_repo_git"])

def get_watermark():
    return(appconfig["watermark"])

def get_watermark_plotly(_fig, _y=0.95):
    _fig.add_annotation(text = (f"<a href='https://charts.bgeometrics.com'>BGeometrics.com</a>"), showarrow=False,
    x=0.5, y=_y, 
    xref='paper', yref='paper',
    xanchor='center', yanchor='middle', 
    opacity=0.5,
    font=dict(size=25, color='grey', family='Courier New, monospace')
    )

def get_watermark_plotly_v2(_fig, _x=0.91, _y=0.02):
    _fig.add_annotation(
        text = (f"<a href='https://charts.bgeometrics.com'>charts.bgeometrics.com</a>"), 
        showarrow=False,
        x=_x, y=_y, 
        xref='paper', yref='paper',
        xanchor='center', yanchor='middle', 
        opacity=0.8,
        font=dict(size=18, color='grey', family='Courier New, monospace')
    )

def get_template_plotly(_fig):
    _name = "template watermark"
    _template = go.layout.Template()
    _template.layout.annotations = [
        dict(
            name=_name,
            text = "BGeometrics.com",
            opacity=0.1,
            font=dict(color="black", size=45),
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.7,
            showarrow=False,
        )
    ]

    _fig.update_layout(template=_template) 

    return _template

def get_template_plotly_alfabitcoin(_fig):
    _name = "template watermark alfabitcoin"
    _template = go.layout.Template()
    _template.layout.annotations = [
        dict(
            name=_name,
            text = "LOGO ALFA BITCOIN",
            opacity=0.1,
            font=dict(color="black", size=45),
            xref="paper",
            yref="paper",
            x=0.5,
            y=0.7,
            showarrow=False,
            )
    ]

    _fig.update_layout(template=_template) 

    return _template

def get_watermark_plotly_alfabitcoin(_fig, _x=0.92, _y=0.02):
    _fig.add_annotation(
            text = (f"Designed by <a href='https://charts.bgeometrics.com'>BGeometrics</a>"), 
        showarrow=False,
        x=_x, y=_y, 
        xref='paper', yref='paper',
        xanchor='center', yanchor='middle', 
        opacity=0.8,
        font=dict(size=14, color='grey', family='Courier New, monospace')
    )

def download_page(url, archive):
    try:
        response = requests.get(url)
        response.raise_for_status()
        
        with open(archive, 'wb') as file:
            file.write(response.content)
        
    except requests.exceptions.RequestException as e:
        print(f"Error access page web: {e}")
    except Exception as e:
        print(f"Error: {e}")

def download_page_check(url, archive):
    if not check_operational():
        print("URL: " + url)
        download_page(url, archive)
        print("Archive: " + archive)
    else:
        print("Exit ")
        print("Archive: " + archive)
        sys.exit()

def extract_text_between_strings_file(archive, string_init, string_end):
    try:
        with open(archive, 'r') as file:
            _file = file.read()

        init_pos = _file.find(string_init)
        end_pos = _file.find(string_end, init_pos + len(string_init))

        if init_pos == -1 or end_pos == -1:
            print("No strings in the text.")
            return None

        _text = _file[init_pos + len(string_init):end_pos]
        
        return _text

    except FileNotFoundError:
        print(f"The archive '{archive}' not found.")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None

def extract_text_between_strings(_text, str_init, str_end):
    try:
        init_pos = _text.find(str_init)
        end_pos = _text.find(str_end, init_pos + len(str_init))
        
        if init_pos == -1 or end_pos == -1:
            print("No strings in the text.")
            return None

        text_res = _text[init_pos + len(str_init):end_pos]
        
        return text_res
        
    except Exception as e:
        print(f"Error: {e}")
        return None
    
def send_telegram_message(token, chat_id, message):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': message
    }
    response = requests.post(url, data=payload)

    return response.json()

def replace_text_in_directory(directory, old_text, new_text, file_extension=None):
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)

        if os.path.isfile(file_path) and (file_extension is None or filename.endswith(file_extension)):
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()

            modified_content = re.sub(re.escape(old_text), new_text, content)

            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(modified_content)

            #print(f"Processed file: {file_path}")
