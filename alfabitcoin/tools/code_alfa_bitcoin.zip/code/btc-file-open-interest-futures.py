#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


_sql = """  
    SELECT btc_price_usd.the_date d, price_usd,
		binance, bybit, okx, bitget, 
		deribit, bitmex, huobi, bitfinex,
		gate_io, kucoin, kraken, crypto_com,
                dydx, delta_exchange
    FROM btc_open_interest, btc_price_usd
    WHERE btc_open_interest.the_date = btc_price_usd.the_date
    ORDER BY btc_price_usd.the_date;
 """

data = utils.get_dataframe_sql(_sql)

_metrics = "open_interest_futures"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"

data.to_csv(_file_csv, index=False)
data.iloc[-1:].to_csv(_file_csv_latest, index=False)

data[['d', 'price_usd']].to_json(_file_price_json, orient="values")

_file_json = config.DIR_FILES + "/oi_binance.json"
data[['d', 'binance']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_bybit.json"
data[['d', 'bybit']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_okx.json"
data[['d', 'okx']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_bitget.json"
data[['d', 'bitget']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_deribit.json"
data[['d', 'deribit']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_bitmex.json"
data[['d', 'bitmex']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_huobi.json"
data[['d', 'huobi']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_bitfinex.json"
data[['d', 'bitfinex']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_gateio.json"
data[['d', 'gate_io']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_kucoin.json"
data[['d', 'kucoin']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_cryptocom.json"
data[['d', 'crypto_com']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_kraken.json"
data[['d', 'kraken']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_dydx.json"
data[['d', 'dydx']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_delta_exchange.json"
data[['d', 'delta_exchange']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/oi_total.json"
data['total'] = data['binance'].fillna(0) + data['bybit'].fillna(0) + data['okx'].fillna(0) + data['bitget'].fillna(0) + data['deribit'].fillna(0) + data['bitmex'].fillna(0) + data['huobi'].fillna(0) + data['bitfinex'].fillna(0) + data['gate_io'].fillna(0) + data['kucoin'].fillna(0) + data['kraken'].fillna(0) + data['crypto_com'].fillna(0) + data['dydx'].fillna(0) + data['delta_exchange'].fillna(0) 

data[['d', 'total']].to_json(_file_json, orient="values")


