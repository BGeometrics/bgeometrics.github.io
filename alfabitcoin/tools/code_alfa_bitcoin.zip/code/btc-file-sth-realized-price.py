#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config

# Select date -> d

_sql = """  
    SELECT btc_price_usd.the_date d, sth_realized_price, price_usd, 
    	sth_realized_price_1m, sth_realized_price_3m   
    FROM btc_lth_sth, btc_price_usd
    WHERE btc_lth_sth.the_date = btc_price_usd.the_date
    AND btc_price_usd.the_date >= '2011-06-01'
    ORDER BY btc_price_usd.the_date;
 """

data = utils.get_dataframe_sql(_sql)
data['sth_dma'] = data['sth_realized_price'].rolling(30).mean()
data['sth_dma_std'] = data['sth_dma'].rolling(30).std()
data['sth_dma_-std'] = data['sth_dma'] - 2 * data['sth_dma_std'] 
data['sth_dma_+std'] = data['sth_dma'] + 2 * data['sth_dma_std'] 

_metrics = "sth_realized_price"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
_file_all_json = config.DIR_FILES + "/"+ _metrics + "_all.json"

data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd', _metrics]].to_json(_file_all_json)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "sth_realized_price_1m"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "sth_realized_price_3m"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "sth_dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "sth_dma_-std"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "sth_dma_+std"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")
