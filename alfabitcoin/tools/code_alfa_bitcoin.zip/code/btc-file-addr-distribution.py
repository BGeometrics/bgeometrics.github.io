#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


_sql = """  
    SELECT btc_price_usd.the_date d, price_usd, 
        humpback address_10k,  
        whale address_10k_1k, 
        shark address_100_1000, 
        fish address_10_100, 
        crab address_1_10, 
        shrimp_01_1 address_01_1, 
        crab + shrimp_01_1 address_01_10 
    FROM btc_address_distribution, btc_price_usd
    WHERE btc_address_distribution.the_date = btc_price_usd.the_date
    AND btc_price_usd.the_date >= '2012-01-01' 
    ORDER BY btc_price_usd.the_date;
 """

data = utils.get_dataframe_sql(_sql)

_metrics = "address_10k"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "address_10k_1k"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "address_100_1000"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "address_10_100"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "address_1_10"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "address_01_1"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "address_01_10"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

