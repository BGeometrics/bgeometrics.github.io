#!/usr/bin/python3

import pandas as pd
import numpy as np
from datetime import datetime, date
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.io as pio
import plotly
import plotly.graph_objects as go
import requests
import bitcoin_utils as utils
import config_alfabitcoin as config


file_ = utils.get_dir_repo_git() + "/reports/bitcoin_price_histogram_g.html"
file_img = utils.get_dir_repo_git() + "/assets/img/gallery/bitcoin-distribution-price.png"
url_web = "https://tsypruyan.github.io/utxo_h.html"
name_archive = "/tmp/Tsypruyan.html"


def get_price_distribution_ext():
    d_today = date.today().strftime("%d %B %Y")
    today = date.today().strftime("%d-%m-%Y")
        
    sql = """
        SELECT the_date, price_usd
        FROM btc_price_usd
        ORDER BY the_date DESC
        LIMIT 1;
    """
    data = utils.get_dataframe_sql(sql)

    utils.download_page(url_web, name_archive)

    srt_init = '"type": "bar", "width": 128, ' 
    srt_end = ', {"line": {"color": "#72B7B2", "'
    text_ext = utils.extract_text_between_strings_file(name_archive, srt_init, srt_end)

    srt_init_x = '"x": ['
    srt_end_x = '], "xaxis": "x", "y":'
    text_ext_x = utils.extract_text_between_strings(text_ext, srt_init_x, srt_end_x)

    srt_init_y = '], "xaxis": "x", "y": ['
    srt_end_y = '], "yaxis": "y"}, {'

    text_ext_y = utils.extract_text_between_strings(text_ext, srt_init_y, srt_end_y)

    list_x = text_ext_x.split(',')
    list_y = text_ext_y.split(',')

    df = pd.DataFrame({'x': list_x, 'y': list_y}, dtype=float)
    df = df.iloc[1:]

    fig = go.Figure()

    fig.add_trace(go.Bar(x=df.x, y=df.y, name="BTC histogram"))

    utils.get_watermark_plotly(fig, _y=0.8)

    fig.add_vline(x=data.price_usd.iloc[0], line_width=1, line_dash='dash')

    fig.add_trace(go.Scatter(
        x=[data.price_usd.iloc[0]], y=[320000],
        text=["BTC price $" + str(data.price_usd.iloc[0]) + "<br>" + str(today)],
        mode="text"
    ))

    fig.add_annotation(dict(font=dict(color='black',size=13),
                                            x=0,
                                            y=-0.1,
                                            showarrow=False,
                                            text="BTC Histogram. Shows the amount and prices at which bitcoins were purchased.",
                                            textangle=0,
                                            xanchor='left',
                                            xref="paper",
                                            yref="paper"))

    fig.update_layout(title="Bitcoin Price (USD) Distribution. " + str(d_today), plot_bgcolor="rgba(0, 0, 0, 0)", showlegend=False)

    fig.write_html(file_, full_html=False, include_plotlyjs='cdn')
    fig.write_image(file_img)

    # File data 
    num_x = 0
    num_y = 0
    rows = []

    for index, row in df.iterrows():
        if (index % 2) == 0:
            rows.append([row['x'], row['y'] + num_y])
            num_y = 0
        else:
            num_y = row['y']

    df2 = pd.DataFrame(rows, columns=["x", "y"])

    file_x_json = config.DIR_FILES + "/histogram_price_x.json"
    file_y_json = config.DIR_FILES + "/histogram_price_y.json"
    file_price_last_json = config.DIR_FILES + "/btc_price_last.json"
    file_price_last_pos = config.DIR_FILES + "/btc_price_last_pos.json"

    df2.x.to_json(file_x_json, orient="values")
    df2.y.to_json(file_y_json, orient="values")
    data.price_usd.to_json(file_price_last_json, orient="values")

    value = data.price_usd.iloc[0]
    result = df2[df2['x'].between(int(value-128), int(value+128))].index[0]

    f = open(file_price_last_pos, 'w')
    f.write(str(result))
    f.close()

    _file_csv = config.DIR_FILES + "/volumen_price_realized.csv"
    df2.to_csv(_file_csv, index=False)

if __name__ == "__main__":
    get_price_distribution_ext()
