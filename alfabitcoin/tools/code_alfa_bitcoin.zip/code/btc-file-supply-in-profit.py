#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


_sql = """  
    SELECT btc_price_usd.the_date d, profit_loss, price_usd,
        profit_lth / 100000000 profit_lth, 
        profit_sth / 100000000 profit_sth,
        (total_lth - profit_lth) / 100000000 loss_lth,
        (total_sth - profit_sth) / 100000000 loss_sth
    FROM btc_supply, btc_price_usd
    WHERE btc_supply.the_date = btc_price_usd.the_date
    ORDER BY btc_price_usd.the_date;
 """

data = utils.get_dataframe_sql(_sql)

_metrics = "profit_loss"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"

data[['d', 'price_usd', _metrics]].to_csv(_file_csv, index=False)
data[['d', 'price_usd', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "profit_lth"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "profit_sth"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "loss_lth"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "loss_sth"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")
