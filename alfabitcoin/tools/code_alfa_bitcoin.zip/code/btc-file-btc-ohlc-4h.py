#!/usr/bin/python3

import pandas as pd
import datetime as dt
from binance.client import Client
import requests
import json
from binance.exceptions import BinanceAPIException, BinanceOrderException
from configparser import ConfigParser
import bitcoin_utils as utils
import yfinance as yf
from configparser import ConfigParser


#Read config.ini file
config_object = ConfigParser()
config_object.read("config.ini")
binance_config = config_object["BINANCE"]
API_KEY_BINANCE = binance_config["API_KEY_BINANCE"]
API_SECRET_BINANCE = binance_config["API_SECRET_BINANCE"]

"""
Load bitcoin ohlc historical and get day bitcoin ohlc 
"""

def get_historical_ohlc_data(symbol,past_days=None,interval=None):
    
    """Returns historcal klines from past for given symbol and interval
    past_days: how many days back one wants to download the data"""
    
    client = Client(API_KEY_BINANCE, API_SECRET_BINANCE)

    if not interval:
        interval='4h' # default interval 4h
    if not past_days:
        past_days=4  # default past 4 days

    start_str=str((pd.to_datetime('today')-pd.Timedelta(str(past_days)+' days')).date())
    
    D = pd.DataFrame(client.get_historical_klines("BTCUSDT", start_str=start_str, interval=interval))

    D.columns=['open_time','open', 'high', 'low', 'close', 'volume', 'close_time', 'qav', 'num_trades', 'taker_base_vol', 'taker_quote_vol','is_best_match']
    D['open_date_time']=[dt.datetime.fromtimestamp(x/1000) for x in D.open_time]
    D['symbol']=symbol
    D=D[['symbol','open_date_time','open', 'high', 'low', 'close', 'volume', 'num_trades', 'taker_base_vol', 'taker_quote_vol']]

    return D

def load_historical_ohlc(symbol,past_days=None,interval=None):
    df = get_historical_ohlc_data(symbol, past_days, interval)

    #print(df)
    for index, row in df.iterrows():
        sql = """INSERT INTO btc_bitcoin_ohlc_4h (the_date, open, high, low, close, volume) 
                    VALUES ('""" + str(row['open_date_time']) + """', """ + str(row['open']) + """
                    , """ + str(row['high']) + """, """ + str(row['low']) + """
                    , """ + str(row['close']) + """, """ + str(row['volume']) + """);"""
        #print(insert)
        try: 
            utils.sql_execute(sql, throw_exception=True)
        except Exception as error:
            sql = """UPDATE btc_bitcoin_ohlc_4h 
                     SET open = """ + str(row['open']) + """, 
                     high = """ + str(row['high']) + """, 
                     low = """ + str(row['low']) + """, 
                     close = """ + str(row['close']) + """, 
                     volume = """ + str(row['volume']) + """ 
                     WHERE the_date = '""" + str(row['open_date_time']) + """';"""
            utils.sql_execute(sql)
            #print(sql)


#date_ini = '2015-01-01'
#date_end = '2017-08-17'
#load_historical_ohlc("BTCUSDT", "3600", "4d")

# Load and update days register in table ohlc
load_historical_ohlc("BTCUSDT", "2", "4h")

