#!/usr/bin/python3

# Execute every 4 hours 

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


_sql = """  
    SELECT the_date d, open, high, low, close, volume  
    FROM btc_bitcoin_ohlc_4h  
    ORDER BY the_date;
 """

data = utils.get_dataframe_sql(_sql)
data['10dma'] = data['close'].rolling(10).mean()
data['20dma'] = data['close'].rolling(20).mean()

_file_json = config.DIR_FILES + "/btc_ohlc_4h.json"
data.to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/btc_ohlc_4h_10dma.json"
data[['d', '10dma']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/btc_ohlc_4h_20dma.json"
data[['d', '20dma']].to_json(_file_json, orient="values")

