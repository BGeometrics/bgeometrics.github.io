#!/usr/bin/python3

#https://github.com/coinmetrics-io/api-client-python
#sudo pip3 install coinmetrics-api-client

import sys
from datetime import date, timedelta
from coinmetrics.api_client import CoinMetricsClient
import bitcoin_utils as utils


print("#### " + sys.argv[0] + " ####")
client = CoinMetricsClient()

asset = ""
the_date = ""
price_usd = ""
yesterday = date.today() - timedelta(days=1)
d1 = yesterday.strftime("%Y-%m-%d")

for metric_data in client.get_asset_metrics(assets='btc', 
                                            metrics=['PriceUSD'], 
                                            frequency='1d',
                                            start_time=d1,
                                             end_time=d1):
    asset = metric_data['asset']
    price_usd = metric_data['PriceUSD']
    the_date = metric_data['time'][0:10]


# Update price close yesterday
sql = "SELECT count(*) AS num FROM btc_price_usd WHERE the_date = '" + the_date + "';"
num = utils.get_value1_sql(sql)

if num == 0:
    sql = "INSERT INTO btc_price_usd (asset, price_usd, the_date) VALUES ('btc'," + str(price_usd) + ", '" + the_date + "');"
else:
    sql = "UPDATE btc_price_usd SET price_usd = " + str(price_usd) + " WHERE the_date = '" + the_date + "';"

print(sql)
utils.sql_execute(sql)

# Se hace en otro script a las 00:02 UTC
"""
# Insert or update price now
price_now, today = utils.get_price_now()
sql = "SELECT count(*) AS num FROM btc_price_usd WHERE the_date = '" + today + "';"
num = utils.get_value1_sql(sql)

if num == 0:
    sql = "INSERT INTO btc_price_usd (asset, price_usd, the_date) VALUES ('btc'," + str(price_now) + ", '" + today + "');"
else:
    sql = "UPDATE btc_price_usd SET price_usd = " + str(price_now) + " WHERE the_date = '" + today + "';"

#print(sql)
utils.sql_execute(sql)
"""
