#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


sql = """
    SELECT the_date d, price_usd
    FROM btc_price_usd
    WHERE the_date >= '2012-01-01'
    ORDER BY btc_price_usd.the_date; """

data = utils.get_dataframe_sql(sql)

bitcoin_data = data.rename({'the_date': 'Date', 'price_usd': 'Close'}, axis=1)
bitcoin_data['10dma'] = bitcoin_data['Close'].rolling(10).mean()
bitcoin_data['20dma'] = bitcoin_data['Close'].rolling(20).mean()
bitcoin_data['40dma'] = bitcoin_data['Close'].rolling(40).mean()
bitcoin_data['50dma'] = bitcoin_data['Close'].rolling(50).mean()
bitcoin_data['155dma'] = bitcoin_data['Close'].rolling(155).mean()
bitcoin_data['200dma'] = bitcoin_data['Close'].rolling(200).mean()
bitcoin_data['200wma'] = bitcoin_data['Close'].rolling(7*200).mean()

bitcoin_data['111dma'] = bitcoin_data['Close'].rolling(111).mean()
bitcoin_data['350dma_x2'] = bitcoin_data['Close'].rolling(350).mean()*2

bitcoin_data = bitcoin_data[200:]
bitcoin_data.reset_index(inplace=True)

_metrics = "moving_average_price"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', 'Close']].to_json(_file_json, orient="values")

_metrics = "10dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "20dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "40dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "50dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "155dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "200dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "200wma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data[['d', _metrics]].to_json(_file_json, orient="values")

start_date = pd.to_datetime("2013-01-01").date()
bitcoin_data_2013 = bitcoin_data[(bitcoin_data.d >= start_date)]

_metrics = "111dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
bitcoin_data_2013[['d', _metrics]].to_json(_file_json, orient="values")
bitcoin_data_2013[['d', 'Close', _metrics]].to_csv(_file_csv, index=False)
bitcoin_data_2013[['d', 'Close', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)

_metrics = "350dma_x2"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
bitcoin_data_2013[['d', _metrics]].to_json(_file_json, orient="values")
bitcoin_data_2013[['d', 'Close', _metrics]].to_csv(_file_csv, index=False)
bitcoin_data_2013[['d', 'Close', _metrics]].iloc[-1:].to_csv(_file_csv_latest, index=False)

_metrics = "pi_cycle_price"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
bitcoin_data_2013[['d', 'Close']].to_json(_file_json, orient="values")

