
DIR_FILES="/home/pi/bgeometrics.github.io/files"

