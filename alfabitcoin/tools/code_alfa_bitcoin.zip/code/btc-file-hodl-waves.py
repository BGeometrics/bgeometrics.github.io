#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


_sql = """  
    SELECT btc_price_usd.the_date d, price_usd, age_0d_1d, age_1d_1w, age_1w_1m,
            age_1m_3m, age_3m_140d + age_140d_6m age_3m_6m, age_6m_1y, age_1y_2y, age_2y_3y,
            age_3y_4y, age_4y_8y, age_8y_,
            age_1y_2y + age_2y_3y + age_3y_4y + age_4y_8y + age_8y_ age_1y_,
            age_6m_1y + age_1y_2y + age_2y_3y + age_3y_4y + age_4y_8y + age_8y_ age_6m_,
            age_0d_1d + age_1d_1w + age_1w_1m + age_1m_3m + age_3m_140d + age_140d_6m age_6m_sth, 
            (age_6m_1y + age_1y_2y + age_2y_3y + age_3y_4y + age_4y_8y + age_8y_)* supply_current / 100 age_6m_lth_supply, 
            (age_0d_1d + age_1d_1w + age_1w_1m + age_1m_3m + age_3m_140d + age_140d_6m) * supply_current / 100 age_6m_sth_supply,
            supply_current             
    FROM btc_hodl_waves_relative, btc_price_usd, btc_realized_price
    WHERE btc_price_usd.the_date = btc_hodl_waves_relative.the_date
    AND btc_realized_price.the_date = btc_price_usd.the_date 
    AND btc_price_usd.the_date >= '2011-01-01'
    ORDER BY btc_price_usd.the_date;
 """

data = utils.get_dataframe_sql(_sql)

_metrics = "hodl_waves"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"

data.to_csv(_file_csv, index=False)
data.iloc[-1:].to_csv(_file_csv_latest, index=False)

data[['d', 'price_usd']].to_json(_file_price_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_0d_1d.json"
data[['d', 'age_0d_1d']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_1d_1w.json"
data[['d', 'age_1d_1w']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_1w_1m.json"
data[['d', 'age_1w_1m']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_1m_3m.json"
data[['d', 'age_1m_3m']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_3m_6m.json"
data[['d', 'age_3m_6m']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_6m_1y.json"
data[['d', 'age_6m_1y']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_1y_2y.json"
data[['d', 'age_1y_2y']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_2y_3y.json"
data[['d', 'age_2y_3y']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_3y_4y.json"
data[['d', 'age_3y_4y']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_4y_8y.json"
data[['d', 'age_4y_8y']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_8y_.json"
data[['d', 'age_8y_']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_1y_.json"
data[['d', 'age_1y_']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_6m_.json"
data[['d', 'age_6m_']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_6m_sth.json"
data[['d', 'age_6m_']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_6m_lth_supply.json"
data[['d', 'age_6m_lth_supply']].to_json(_file_json, orient="values")

_file_json = config.DIR_FILES + "/hw_age_6m_sth_supply.json"
data[['d', 'age_6m_sth_supply']].to_json(_file_json, orient="values")

