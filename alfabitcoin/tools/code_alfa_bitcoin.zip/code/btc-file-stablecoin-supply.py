#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


_sql = """  
    SELECT btc_price_usd.the_date d, price_usd,
            bss.usdt, bss.usdc, bss.dai, 
            bss.busd, pax, bss.gusd, 
            bss.usdt + bss.usdc + bss.dai + bss.busd + bss.pax + bss.gusd stablecoins 
    FROM btc_stablecoin_supply bss, btc_price_usd
    WHERE bss.the_date = btc_price_usd.the_date
    ORDER BY btc_price_usd.the_date;
"""

data = utils.get_dataframe_sql(_sql)

_metrics = "stablecoin_supply"
_file_csv = config.DIR_FILES + "/"+ _metrics + ".csv"
_file_csv_latest = config.DIR_FILES + "/"+ _metrics + "_latest.csv"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
_file_all_json = config.DIR_FILES + "/"+ _metrics + "_all.json"
data.to_csv(_file_csv, index=False)
data.iloc[-1:].to_csv(_file_csv_latest, index=False)
data.to_json(_file_all_json)

data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
_file_json = config.DIR_FILES + "/stablecoin_usdt.json"
data[['d', 'usdt']].to_json(_file_json, orient="values")
_file_json = config.DIR_FILES + "/stablecoins.json"
data[['d', 'stablecoins']].to_json(_file_json, orient="values")
_file_json = config.DIR_FILES + "/stablecoin_usdc.json"
data[['d', 'usdc']].to_json(_file_json, orient="values")
_file_json = config.DIR_FILES + "/stablecoin_dai.json"
data[['d', 'dai']].to_json(_file_json, orient="values")
_file_json = config.DIR_FILES + "/stablecoin_busd.json"
data[['d', 'busd']].to_json(_file_json, orient="values")
_file_json = config.DIR_FILES + "/stablecoin_pax.json"
data[['d', 'pax']].to_json(_file_json, orient="values")
_file_json = config.DIR_FILES + "/stablecoin_gusd.json"
data[['d', 'gusd']].to_json(_file_json, orient="values")

