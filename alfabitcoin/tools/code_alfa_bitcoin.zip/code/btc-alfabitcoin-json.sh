#!/bin/bash

python3 btc-file-addr-distribution.py
python3 btc-file-address-active.py
python3 btc-file-btc-ohlc-4h.py
python3 btc-file-capitalization.py
python3 btc-file-capitalization.py
python3 btc-file-hodl-waves.py
python3 btc-file-mvrv-zscore.py
python3 btc-file-nupl.py
python3 btc-file-nvt.py
python3 btc-file-nvt.py
python3 btc-file-open-interest-futures.py
python3 btc-file-price.py
python3 btc-file-realized-price.py
python3 btc-file-sopr.py
python3 btc-file-stablecoin-supply.py
python3 btc-file-sth-realized-price.py
