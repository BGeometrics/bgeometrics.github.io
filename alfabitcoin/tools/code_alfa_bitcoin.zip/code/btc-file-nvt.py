#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config

"""
https://capriole.com/bitcoin-valuation-using-dynamic-range-nvt-signal/
https://es.tradingview.com/script/CvHeBiMw-mab-Dynamic-Bitcoin-NVT-Signal/

    Overbought: NVT Signal > 2-year mean +2.0 * standard deviations
    Oversold: NVT Signal < 2-year mean — 0.5 * standard deviations

    btc_market_cap = request.security("COINMETRICS:BTC_MARKETCAPFF","D", ta.sma(close, mcMaLength -> 1 day))
    btc_trans_vol = request.security("COINMETRICS:BTC_TXVOLUMEUSD","D", ta.sma(close, tvMaLength -> 90 days))
    nvt = btc_market_cap / btc_trans_vol

    // Calculate adjusted NVTS if selected
    nvt := calculationInput == "Adj. NVTS" ? nvt - ta.sma(nvt, 730) : nvt

    // Calculate MA and dynamic overbought and oversold values
    nvtMa = ma(nvt, maLengthInput -> 730 , maTypeInput -> SMA)
    dev = ta.stdev(nvt, maLengthInput)
    overbought = nvtMa + (obMultiInput * dev)
    oversold = nvtMa - (osMultiInput * dev)
    oversold = nvtMa - (osMultiInput * dev)

Utilizo mi propio índice tx_volume_usd porque no me convencen los de glassnode, coinmetrics e IntoTheBlock parece que no restan el cambio.
El bueno es el de quantl pero no tengo acceso
"""


sql = """  
    SELECT btc_price_usd.the_date d, nvtadj90, price_usd,
        market_cap_ff_glassnode market_cap_ff, tx_volume_usd_glassnode tx_volume_usd 
    FROM btc_nvt, btc_price_usd
    WHERE btc_nvt.the_date = btc_price_usd.the_date
    AND btc_price_usd.the_date >= '2012-01-01'
    ORDER BY btc_price_usd.the_date;
 """

std_overbought = 2
std_oversold = 0.5

data = utils.get_dataframe_sql(sql)
data['tx_volume_usd_90dma'] = data['tx_volume_usd'].rolling(90).mean()
data['nvts'] = data['market_cap_ff'] / data['tx_volume_usd_90dma']
data['nvts_730dma'] = data['nvts'].rolling(730).mean()
data['nvts_adj'] = data['nvts'] - data['nvts_730dma']
data['nvts_730dma_std'] = data['nvts'].rolling(730).std()
data['nvts_730dma_high'] = data['nvts_730dma'] + (data['nvts_730dma_std'] * std_overbought)
data['nvts_730dma_low'] = data['nvts_730dma'] - (data['nvts_730dma_std'] * std_oversold)

data['date'] = pd.to_datetime(data['d'])

df = data[data['date'] > '2014-04-01']

_metrics = "nvts"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
df[['d', 'price_usd']].to_json(_file_price_json, orient="values")

_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
df[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "nvts_730dma"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
df[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "nvts_730dma_high"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
df[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "nvts_730dma_low"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
df[['d', _metrics]].to_json(_file_json, orient="values")

