#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


_sql = """  
    SELECT btc_price_usd.the_date d, sopr, price_usd, lth_sopr, sth_sopr
    FROM btc_sopr, btc_price_usd
    WHERE btc_sopr.the_date = btc_price_usd.the_date
    AND btc_price_usd.the_date >= '2012-01-01'
    ORDER BY btc_price_usd.the_date;
 """

data = utils.get_dataframe_sql(_sql)

_metrics = "sopr"
_file_price_json = config.DIR_FILES + "/" + _metrics + "_btc_price.json"
data[['d', 'price_usd']].to_json(_file_price_json, orient="values")
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")
_metrics = "lth_sopr"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")
_metrics = "sth_sopr"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")
