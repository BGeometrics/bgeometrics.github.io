#!/usr/bin/python3

import pandas as pd
import numpy as np
import bitcoin_utils as utils
import config_alfabitcoin as config


# Thermocap only data 8-2020 but it is posible execute proccess for get data old, 
# es la suma del precio de los BTC cuando se minaron. Mercado primario
_sql = """  
    SELECT btc_price_usd.the_date d, price_usd,  
            market_cap, thermo_cap, cap_real_usd realized_cap_capitalization, 
            thermo_cap / cap_real_usd thermocap_realizedcap_ratio, 
            cap_real_usd - thermo_cap investor_cap
    FROM btc_realized_price, btc_miner, btc_price_usd
    WHERE btc_realized_price.the_date = btc_price_usd.the_date
    AND btc_realized_price.the_date = btc_miner.the_date 
    AND btc_realized_price.the_date >= '2013-05-01' 
    ORDER BY btc_price_usd.the_date;
 """

data = utils.get_dataframe_sql(_sql)

_metrics = "realized_cap_capitalization"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "market_cap"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "thermo_cap"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "thermocap_realizedcap_ratio"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

_metrics = "investor_cap"
_file_json = config.DIR_FILES + "/"+ _metrics + ".json"
data[['d', _metrics]].to_json(_file_json, orient="values")

